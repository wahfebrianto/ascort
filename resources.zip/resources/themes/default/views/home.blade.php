@extends('layouts.master')

@section('content')
    <h1>Welcome</h1>
    <div class="box-body">
        Mei ad adhuc summo cetero. Qui assum habemus signiferumque cu,
        per idque evertitur cu, doming corpora deserunt te vis. Melius
        oporteat ea usu. Timeam tincidunt cum et. Eam justo utroque no.
        Enim aliquando abhorreant ea sea, vis ex efficiendi referrentur,
        ei pro tacimates sadipscing. Et consulatu gloriatur
        signiferumque vim, an solum antiopam periculis cum.
    </div>
    <div class="box-body">
        Erat equidem ad sed. No has altera voluptatum, sit agam possim
        bonorum no. Munere delenit duo eu. Sed prompta vivendum detraxit
        an.
        Ex recusabo suscipiantur vim, eam legendos scriptorem cu. Cum ex
        nibh offendit adipiscing. Ea has iriure atomorum, iudico commodo
        ut usu. Eruditi fierent fastidii in has, vix diam decore putent
        ad. Hinc tollit minimum et sit, munere putent assueverit pri id.
    </div>
    <div class="box-body">
        Bonorum admodum contentiones vis in. Ne eum hinc minim adolescens.
        Ea eum veniam delectus philosophia, nam ad cibo cotidieque, integre
        inermis mea an. Movet equidem lobortis in has, vel ad eripuit
        debitis accusamus.
        Offendit recteque cu pri, mel id solet dicant. Ea reque iriure ius,
        te virtute euripidis referrentur his, mea legere semper melius cu.
        Eu pri utroque percipit contentiones. Pri timeam fierent ad, ne
        menandri perpetua delicatissimi vis. Sanctus ullamcorper no mea. Ex
        vel rebum erant.
        Ius dolorum persecuti ea. Duo at quot expetenda. Id possim delenit
        epicuri mei. Ei eum graeco legimus vulputate. Quas dicat vim id, pro
        id dolor consetetur, vel cu aeque pertinax qualisque. Et vim agam
        graeci, vis purto accusam ex.
    </div>


@endsection
