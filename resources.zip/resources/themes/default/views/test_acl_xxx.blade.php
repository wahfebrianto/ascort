@extends('layouts.master')

@section('content')
    <h1>ACL TEST!</h1>
    <div class="box-body">
        {{ $page_message }}
    </div>
@endsection
