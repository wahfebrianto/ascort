@extends('layouts.master')

@section('content')
    <h1>Hello!</h1>
    <div class="box-body">
        Just a little page to test the flash messages!
    </div>
@endsection
