<!-- Sidebar Menu -->
<ul class="sidebar-menu">

    {!! $menuContent !!}

</ul><!-- /.sidebar-menu -->
