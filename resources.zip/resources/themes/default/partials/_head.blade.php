<!-- Head for the theme -->
@include('partials._theme_head')
