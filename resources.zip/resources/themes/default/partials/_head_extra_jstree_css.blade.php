<!-- JSTree 3.2.1 -->
<link href="{{ asset("/jstree/dist/themes/default/style.min.css") }}" rel="stylesheet" type="text/css" />
<!-- Bootstrap theme for JSTree -->
<link href="{{ asset("/jstree/dist/themes/proton/style.min.css") }}" rel="stylesheet" type="text/css" />
