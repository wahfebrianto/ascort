<!-- Select2 4.0.0 -->
<link href="{{ asset("/bower_components/admin-lte/select2/css/select2.min.css") }}" rel="stylesheet" type="text/css" />
<!-- Select2-bootstrap-theme 0.1.0-beta.4 -->
<link href="{{ asset("/bower_components/admin-lte/select2/css/select2-bootstrap.min.css") }}" rel="stylesheet" type="text/css">
