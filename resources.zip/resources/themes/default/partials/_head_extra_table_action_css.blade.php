<style>
    .column-action {
        width: 250px;
    }
</style>