<div class="header-logo">
    <table>
        <tr>
            <td colspan="2" rowspan="4" style="padding-right: 0.5cm;"><img src="{{ asset('/assets/images/logo-print.jpg?'.time()) }}" style="width: 2cm" /></td>
            <td><strong>{{ config('names.perusahaan') }}</strong></td>
        </tr>
        <tr><td>{{ config('names.keterangan_perusahaan') }}</td></tr>
        <tr><td>{{ config('names.alamat') }}</td></tr>
        <tr><td>{{ config('names.kota') }}</td></tr>
    </table>
    <div class="border-bottom-decor" style="width: 100%; margin: 0.25cm 0 1cm 0;"></div>
</div>
