<!-- AdminLTE Skins. We have chosen the skin-green for this starter
                                                      page. However, you can choose any other skin. Make sure you
      apply the skin class to the body tag so the changes take effect.
-->
<link href="{{ asset("/bower_components/admin-lte/dist/css/skins/skin-green.min.css") }}" rel="stylesheet" type="text/css" />
