<?php

return [

    'delete-confirm'              => [
        'title'   => 'Delete role',
        'body'    => 'Are you sure that you want to delete role ID :id with the name ":name"? This operation is irreversible.',
    ],


];
