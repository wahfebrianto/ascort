<?php

return [

    'delete-confirm'              => [
        'title'   => 'Delete menu',
        'body'    => 'Are you sure that you want to delete menu ID :id with the label ":label"? This operation is irreversible.',
    ],


];
